import { z } from "zod";

export const loginSchema = z.object({
  email: z
    .email("Please enter a valid email address.")
    .trim(),

  password: z
    .string()
    .min(6, "Password must be at least 6 characters."),

  remember: z.boolean(),
});

export type LoginFormData = z.infer<typeof loginSchema>;