import { ReportsDashboardPage } from "@/features/reports/pages/ReportsDashboardPage";

function Dashboard() {
  return <ReportsDashboardPage />;
}

export default Dashboard;